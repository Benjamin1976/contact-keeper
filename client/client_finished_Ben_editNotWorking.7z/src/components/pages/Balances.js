import React from 'react';
import BalancesTag from '../balances/Balances';

const Balances = () => {
  return (
    <div className='grid-1'>
      <div>
        <BalancesTag />
      </div>
    </div>
  );
};

export default Balances;
