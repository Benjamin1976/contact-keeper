import {
  ADD_BALANCE,
  DELETE_BALANCE,
  SET_CURRENT_BALANCE,
  CLEAR_CURRENT_BALANCE,
  UPDATE_BALANCE,
  FILTER_BALANCES,
  CLEAR_FILTER_BALANCE
} from '../types';

export default (state, action) => {
  switch (action.type) {
    case ADD_BALANCE:
      return {
        ...state,
        balances: [...state.balances, action.payload]
        // as above state is being passed and state is immutable, need to make a copy
      };

    case DELETE_BALANCE:
      return {
        ...state,
        balances: state.balances.filter(
          balance => balance.id !== action.payload
        )
        //   state.filtered === null
        //     ? state.balances.filter(balance => balance.id !== action.payload)
        //     : null,
        // filtered:
        //   state.filtered !== null
        //     ? state.balances.filter(balance => balance.id !== action.payload)
        //     : null
      };

    case UPDATE_BALANCE:
      return {
        ...state,
        balances: state.balances.map(balance =>
          balance.id === action.payload.id ? action.payload : balance
        )
      };

    case SET_CURRENT:
      return {
        ...state,
        current_balance: action.payload
        // ,
        // filtered: state.filtered !== null ? null : action.payload
      };
    case CLEAR_CURRENT:
      return {
        ...state,
        current_balance: null
      };
    case FILTER_BALANCES:
      return {
        ...state,
        filtered: state.balances.filter(balance => {
          const regex = new RegExp(`${action.payload}`, 'gi');
          return balance.name.match(regex) || balance.email.match(regex);
        })
      };
    case CLEAR_FILTER:
      return {
        ...state,
        filtered: null
      };
    default:
      return state;
  }
};
