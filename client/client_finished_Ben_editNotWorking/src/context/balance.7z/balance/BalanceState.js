import React, { useReducer } from 'react';
import { v4 as uuid } from 'uuid';
import BalanceContext from './balanceContext';
import balanceReducer from './balanceReducer';
import {
  ADD_BALANCE,
  DELETE_BALANCE,
  SET_CURRENT_BALANCE,
  CLEAR_CURRENT_BALANCE,
  UPDATE_BALANCE,
  FILTER_BALANCE,
  CLEAR_FILTER_BALANCE
} from '../types';

const BalanceState = props => {
  const initialState = {
    contacts: [
      {
        id: 1,
        name: 'Jill Johnson',
        email: 'jill@gmail.com',
        phone: '111-111-1111',
        type: 'personal'
      },
      {
        id: 2,
        name: 'Sara Watson',
        email: 'sara@gmail.com',
        phone: '222-222-2222',
        type: 'personal'
      },
      {
        id: 3,
        name: 'Harry White',
        email: 'harry@gmail.com',
        phone: '333-333-3333',
        type: 'professional'
      }
    ],
    current: null,
    filtered: null
  };

  const [state, dispatch] = useReducer(balanceReducer, initialState);

  // Add Contact
  const addBalance = balance => {
    balance.id = uuid;
    dispatch({ type: ADD_BALANCE, payload: balance });
  };

  // Delete Contact
  const deleteBalance = id => {
    dispatch({ type: DELETE_BALANCE, payload: id });
  };

  // Set Current Contact
  const setCurrentBalance = balance => {
    dispatch({
      type: SET_CURRENT_BALANCE,
      payload: balance
    });
  };

  // Clear Current Contact
  const clearCurrentBalance = () => {
    dispatch({ type: CLEAR_CURRENT_BALANCE });
  };

  // Update Contact
  const updateContactBalance = balance => {
    dispatch({ type: UPDATE_BALANCE, payload: balance });
  };

  // Filter Contacts
  const filterBalances = text => {
    dispatch({ type: FILTER_BALANCES, payload: text });
  };

  // Clear Filter
  const clearBalanceFilter = () => {
    dispatch({ type: CLEAR_FILTER_BALANCE });
  };

  return (
    <BalanceContext.Provider
      value={{
        balances: state.balances,
        balance: state.current_balance,
        filtered: state.filtered_balance,
        addBalance,
        deleteBalance,
        setCurrentBalance,
        clearCurrentBalance,
        updateBalance,
        filterBalances,
        clearBalanceFilter
      }}
    >
      {props.children}
    </BalanceContext.Provider>
  );
};

export default BalanceState;
