import React from 'react';
import BalancesTag from '../balances/Balances';
import BalancesForm from '../balances/BalancesForm';

const Balances = () => {
  return (
    <div className='grid-1'>
      <div>
        <BalancesForm />
      </div>
      <div>
        <BalancesTag />
      </div>
    </div>
  );
};

export default Balances;
