import React, { useState, useContext, useEffect } from 'react';
import BalanceContext from '../../context/balance/balanceContext';
import { FILTER_BALANCE } from '../../context/types';

const BalanceForm = () => {
  const balanceContext = useContext(BalanceContext);

  const {
    current,
    addBalance,
    updateBalance,
    clearCurrentBalance
  } = balanceContext;
  // const contactContext = useContext(ContactContext);

  // const { addContact, clearCurrent, updateContact, current } = contactContext;

  useEffect(() => {
    if (current !== null) {
      setBalance(current);
    } else {
      setBalance({
        id: '',
        account: '',
        type: '',
        value: ''
      });
    }
  }, [balanceContext, current]);

  // useEffect(() => {
  //   if (current !== null) {
  //     setContact(current);
  //   } else {
  //     setContact({
  //       name: '',
  //       email: '',
  //       phone: '',
  //       type: 'personal'
  //     });
  //   }
  // }, [contactContext, current]);
  // only change if currentContext is changed or current is changed

  const [balance, setBalance] = useState({
    id: '',
    account: '',
    type: '',
    value: ''
  });

  const { id, account, type, value } = balance;
  // // only change if currentContext is changed or current is changed

  // const [contact, setContact] = useState({
  //   name: '',
  //   email: '',
  //   phone: '',
  //   type: 'personal'
  // });

  // const { name, email, phone, type } = contact;

  const onChange = e =>
    setBalance({
      ...balance,
      [e.target.name]: e.target.value
    });

  // const onChange = e =>
  //   setContact({
  //     ...contact,
  //     [e.target.name]: e.target.value
  //   });

  const onSubmit = e => {
    e.preventDefault();

    if (current === null) {
      addBalance(balance);
    } else {
      updateBalance(balance);
      clearCurrentBalance();
    }
    // clearAll();
  };

  const clearAll = () => {
    // clearCurrentBalance();
  };

  // const onSubmit = e => {
  //   e.preventDefault();

  //   if (current === null) {
  //     addContact(contact);
  //   } else {
  //     updateContact(contact);
  //   }
  //   clearAll();
  // };

  // const clearAll = () => {
  //   clearCurrent();
  // };

  return (
    <div>
      <form onSubmit={onSubmit}>
        <table>
          <tr>
            <td colspan='4'>
              <h2 className='text-primary'>
                {current ? 'Edit' : 'Add'} Balance
              </h2>
            </td>
          </tr>
          <tr>
            <td>
              <input
                type='text'
                name='account'
                placeholder='account'
                value={account}
                onChange={onChange}
              />
            </td>
            <td>
              <input
                type='text'
                name='type'
                placeholder='type'
                value={type}
                onChange={onChange}
              />
            </td>
            <td>
              <input
                type='text'
                name='value'
                placeholder='balance'
                value={value}
                onChange={onChange}
              />
            </td>
            <td>
              <div>
                <input
                  type='submit'
                  value={current ? 'Save' : 'Add'}
                  className='btn btn-primary btn-block'
                />
              </div>
              {current && (
                <div>
                  <button
                    className='btn-light btn-block'
                    onClick={() => clearCurrentBalance()}
                  >
                    Clear
                  </button>
                </div>
              )}
            </td>
          </tr>
        </table>
      </form>
    </div>
  );
};

export default BalanceForm;
