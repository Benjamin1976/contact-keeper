import React, { Fragment, useState, useContext, useEffect } from 'react';
import BalanceItem from './BalanceItem';
import BalanceContext from '../../context/balance/balanceContext';

const Balances = () => {
  const balanceContext = useContext(BalanceContext);
  const { balances } = balanceContext;

  return (
    <Fragment>
      <h1>Balances</h1>
      <table>
        <tr>
          <th>Account</th>
          <th>Type</th>
          <th>Balance</th>
          <th>Action</th>
        </tr>
        <tbody>
          {balances.map(balance => (
            <BalanceItem balance={balance} />
          ))}
        </tbody>
      </table>
    </Fragment>
  );
};

export default Balances;
