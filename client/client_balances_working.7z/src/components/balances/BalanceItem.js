import React, { Fragment, useState, useContext, useEffect } from 'react';
import BalanceContext from '../../context/balance/balanceContext';

const BalanceItem = ({ balance }) => {
  const balanceContext = useContext(BalanceContext);

  const { current, deleteBalance, setCurrentBalance } = balanceContext;

  const { id, account, type, value } = balance;

  const newRow = current == null;

  const editBalance = () => {
    console.log('edit balance');
  };
  const onDelete = () => {
    deleteBalance(id);
  };

  return (
    <Fragment>
      <tr>
        <td>{account}</td>
        <td>{type}</td>
        <td>{value}</td>
        <td>
          <button onClick={() => setCurrentBalance(balance)}>
            {newRow ? 'Edit' : 'Edit'}
          </button>
          <button onClick={onDelete}>{newRow ? 'Delete' : 'Delete'}</button>
        </td>
      </tr>
    </Fragment>
  );
};

export default BalanceItem;
