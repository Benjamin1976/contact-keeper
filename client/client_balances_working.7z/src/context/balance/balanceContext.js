import { createContext } from 'react';

const balanceContext = createContext();

export default balanceContext;
