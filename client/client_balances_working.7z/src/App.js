import React, { Fragment } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import About from './components/pages/About';
import Home from './components/pages/Home';
import Balances from './components/pages/Balances';
import ContactState from './context/contact/ContactState';
import './App.css';
import BalanceState from './context/balance/BalanceState';

const App = () => {
  return (
    <BalanceState>
      <ContactState>
        <Router>
          <Fragment>
            <Navbar />
            <div className='container'>
              <Switch>
                <Route exact path='/' component={Home} />
                <Route exact path='/about' component={About} />
                <Route exact path='/balances' component={Balances} />
              </Switch>
            </div>
          </Fragment>
        </Router>
      </ContactState>
    </BalanceState>
  );
};

export default App;
